package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Destination")
public class Destination extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Destination() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// tester si l'utilisateur a �t� authentifi� et autoris� � voir cette page
		
		HttpSession s = request.getSession();
		String html;
		
		if (s == null || s.getAttribute("user")  == null || s.getAttribute("niveauAutorisation") == null){
			html = "<html><body>" +
						  "<a href='login.html'>Login</a>" +
						  "</body></html>";
			response.getWriter().println(html);
			return;
		}
		
		// v�rifier aussi le niveau d'autorisation (qui doit �tre 2), pas seulement
		// sa pr�sence
		int niveau = ((Integer)s.getAttribute("niveauAutorisation")).intValue();
		
		if (niveau < 2){
			html = "<html><body>Niveau d'autorisation insuffisant<br/><br/>" + 
					"<a href='login.html'>Login</a>" +
					"</body></html>";
		}
		
		html = "<html><body>";
		html += "Bienvenue " + s.getAttribute("user") + " sur notre partie priv�e du site";
		html += "<br/><br/><a href='InvaliderSession'>Se d�connecter</a>";
		html += "</body></html>";
		
		response.getWriter().println(html);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
