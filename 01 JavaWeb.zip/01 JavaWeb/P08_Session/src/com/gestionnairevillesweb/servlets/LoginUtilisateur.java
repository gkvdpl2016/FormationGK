package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginUtilisateur")
public class LoginUtilisateur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginUtilisateur() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// r�cuperer le compte utilisateur et le mot de passe qui ont �t� saisis
		String utilisateur = request.getParameter("utilisateur");
		String mdp = request.getParameter("pwd");
		
		// v�rifier si le compte et le mdp sont valides et
		// donner un certain niveau d'autorisation � l'utilisateur authentifi�
		int niveauAutorisation = 0;
		
		if ((utilisateur.equalsIgnoreCase("val")) && (mdp.equals("pwd1"))) {

			niveauAutorisation = 1;
		}
		
		else if ((utilisateur.equalsIgnoreCase("val")) && (mdp.equals("pwd2"))) {
			niveauAutorisation = 2;
		}
		else
		{
			String html = "<html><body>Echec connexion<br/>";
			html += "<a href='login.html'>Se connecter</a>";
			html += "</body></html>";
			response.getWriter().println(html);
			return;
		}
		
		// utiliser la session pour stocker
		// - le compte utilisateur
		// - le niveau d'autorisation
		// - �ventuellement d'autres informations concernant cet utilisateur
		
		// Session: conteneur sp�cifique � chaque utilisateur (autrement dit,
		// chaque utilisateur a sa propre session)
		// Attention, une session a un certain temps de vie d�finie par la 
		// configuration du serveur (d'habitude) ou par l'application 
		// (dans la plupart des cas, il s'agit des 60 mins d'inactivit�)
		
		// r�cup�rer la session
		HttpSession session = request.getSession();
		
		// stocker dans la session :
		// - le compte utilsateur
		session.setAttribute("user", utilisateur);
		
		// - le niveau d'autorisation
		session.setAttribute("niveauAutorisation", niveauAutorisation);
		
		// selon le niveau d'autorisation d'un utilisateur authentifi�
		// lui fournir un contenu ou un autre
		
		if (niveauAutorisation < 2)
		{
			String html = "<html><body>Votre niveau d'autorisation ne vous permet pas " +
					"de consulter la page demand�e <br/>";
			html += "<a href='login.html'>Se connecter</a>";
			response.getWriter().println(html);
			return;
		}
		
		// l'utilisateur a �t� authentifi� et il a le niveau d'autorisation
		// suffisant pour le diriger vers la page de destination
		response.sendRedirect("/GestionnaireVilles/Destination");
	}

}
