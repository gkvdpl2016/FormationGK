package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/InvaliderSession")
public class InvaliderSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public InvaliderSession() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// pour consid�rer l'utilisateur d�connect� (non loqu�), je dois
		// supprimer les informations de sa session
		
		// pour cela, on peut supprimer la session
		HttpSession s = request.getSession();
		s.invalidate();
		
		String html = "<html><body><h3>Vous avez �t� d�connect�.<br/><br/>" +
				"<a href='login.html'>Se reconnecter</a></body></html>";
		
		response.getWriter().println(html);	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
