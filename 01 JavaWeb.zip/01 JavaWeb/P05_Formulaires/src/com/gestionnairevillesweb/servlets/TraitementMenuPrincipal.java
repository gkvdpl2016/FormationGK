package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TraitementMenuPrincipal")
public class TraitementMenuPrincipal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TraitementMenuPrincipal() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String html = "";
		
		// r�cup�rer � partir de l'objet request, les donn�es saisies
		// par l'utilisateur
		
		// Rappel: les donn�es sont li��es aux noms des contr�les
		
		// r�cup�rer l'item choisi dans la bo�te <select> 
		// (dont le nom est "menuChoisir")
		// Le nom du contr�le dont je cherche la valeur saisie
		// ou s�lectionn�e devient cl� dans request
		// Je cherche donc la valeur attach�e � cette cl� avec la m�thode
		// getParameter();
		String choixUtilisateur = request.getParameter("menuChoisir");
			
		html += choixUtilisateur + "<br/>";
			
		// r�cup�rer l'information des 2 cases � cocher ayant le m�me nom
		String[] tbOptionsUtilisateur = request.getParameterValues("optionsAdmin");
		
		// attention: si aucune des 2 cases � cocher n'a �t� coch�e,
		// aucune information ne remonte vers le serveur attach�e � la cl�
		// optionsAdmin
		// Dans ce cas, request ne contient m�me pas cette cl� donc la m�thode
		// getParameterValues("optionsadmin") return null (car la cl� n'existe pas)
		
		if (tbOptionsUtilisateur != null)
		{
			for (int i = 0; i < tbOptionsUtilisateur.length; i++){
				html += tbOptionsUtilisateur[i] + "<br/>";
			}
		} 
		
		// r�cup�rer la valeur s�lectionn�e des boutons radio
		String optionRadio = request.getParameter("groupeRadio");
		html += optionRadio + "<br/>";
				
		// System.out.println(html);
		
		html = "<html><body><h5>Les donn�es r�cup�r�es � partir de la saisie.</h5></br/>" + html + "</body>";
		
		PrintWriter sortie = response.getWriter();
		sortie.println(html);
		
		// response.getWriter();
		
		// Etape 2
		// Rediriger l'utilisateur vers une autre servlet avec sendRedirect()
		// Comme sendRedirect() utilise l'url pour passer les 
		// donn�es � l'aide d'une querystring, la servlet destinataire utilisera doGet()
		// pour traiter cette nouvelle requ�te
		
		// cr�er la querystring
		StringBuilder querystring = new StringBuilder("");
		
		if (tbOptionsUtilisateur != null)
		{
			for (int i = 0; i < tbOptionsUtilisateur.length; i++){
				
				if (querystring.length() > 0)
					querystring.append("&");
				else
					querystring.append("?");
				
				if (tbOptionsUtilisateur[i].equalsIgnoreCase("utiliserDB"))
					querystring.append("db=1");
				else if (tbOptionsUtilisateur[i].equalsIgnoreCase("envoyerEmail"))
					querystring.append("email=1");	
				
			}
		} // fin if (tbOptionsUtilisateurs != null)
		
		// analyser le choix que l'utilisateur a fait dans la bo�te <select> "menuChoisir"
		// et l'envoyer sur la bonne vue (view) - Ici la servlet joue le r�le du contr�leur
		// (le C de l'architecture MVC)
		if (choixUtilisateur.equals("1"))
			response.sendRedirect("AfficherVilles.html" + querystring); // rediriger vers...
		else if (choixUtilisateur.equals("2"))
			response.sendRedirect("AjouterVille.html" + querystring);
		else if (choixUtilisateur.equals("3"))
			response.sendRedirect("SupprimerVille.html" + querystring);
		else
			response.sendRedirect("index.html");
		
		
		
	} // fin doPost()

}// fin classe TraitementMenuChoisir
