package com.etudiant.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/toto/bonjour2.do")
public class MaPremiereServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MaPremiereServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double valeur = Math.sqrt(4.0);
		Calendar cal = Calendar.getInstance();

		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.YYYY hh:mm:ss");
		String txtHeure = sdf.format(cal.getTime());
		
		PrintWriter sortie = response.getWriter();
		
		sortie.println();
		
		String html = "<html>";
		html += "<body><h3>Bonjour de la part de MaPremi�reServlet</h3></body>";
		html += "<br/>La racine carr�e de 4.0 est " + valeur + "<br/><br/>La date courante : " + txtHeure ;
		html += "</html>";
		sortie.println(html);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
