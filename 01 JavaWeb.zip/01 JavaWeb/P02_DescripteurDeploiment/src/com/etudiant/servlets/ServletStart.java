package com.etudiant.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletStart")
public class ServletStart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletStart() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// on peut (et il est conseill� de pr�ciser le type MIME du contenu envoy�
		// Dans mon cas, il s'agit d'un texte qui doit interpr�ter comme �tant du code
		// html
		// Pour voir les types MIME disponibles, consulter
		// https://fr.wikipedia.org/wiki/Type_MIME
		
		response.setContentType("text/html");
		response.getWriter().println("<html><body><h3 style='color:blue;'>Servlet start</h3></body></html>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
