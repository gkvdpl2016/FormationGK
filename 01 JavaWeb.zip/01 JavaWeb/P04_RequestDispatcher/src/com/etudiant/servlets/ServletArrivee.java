package com.etudiant.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletArrivee.do")
public class ServletArrivee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletArrivee() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		
			Thread.sleep(1000);
			response.setContentType("text/html");
		
			response.getWriter().println("<html><body><h3 style='color: green;'>Servlet arriv�e</h3></body></html>");
		
			System.out.println("Je suis dans ServletArrivee");
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
