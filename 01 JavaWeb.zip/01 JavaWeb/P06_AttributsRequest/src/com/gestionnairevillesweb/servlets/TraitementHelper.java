package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TraitementHelper")
public class TraitementHelper extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TraitementHelper() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String parametres = "";
		
		// l'objet request qui arrive contient aussi bien
		// - la param�tre contenant les valeurs saisies dans le formulaire que
		// - les attributs ajout�s par la servlet TraitementmenuPrincipal2
		
		String selection = request.getParameter("menuChoisir");
		parametres += selection + " ";
		
		String[] tb = request.getParameterValues("optionsAdmin");
		
		if (tb != null)
			for (int i=0; i<tb.length ; i++)
				parametres += tb[i] + " ";

		String html = "<html><body>Donn�es transmises � l'aide des param�tres : <br/>"
				+ parametres;
		
		html += "<br/><br/>Donn�es transmises � l'aide des attributs : <br/>";
		html += "cle : db, valeur : " + request.getAttribute("db");
		html += "<br/>cle : email, valeur : " + request.getAttribute("email");
		
		html += "</body></html>";
		
		response.getWriter().println(html);
	}

}
