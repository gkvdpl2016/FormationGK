package com.gestionnairevillesweb.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TraitementMenuPrincipal2")
public class TraitementMenuPrincipal2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TraitementMenuPrincipal2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// getParameter();
		String choixUtilisateur = request.getParameter("menuChoisir");
		String choix = "";
		switch(choix){
			case "1":
				choix = "afficher";
				break;
			case "2":
				choix = "ajouter";
				break;
			case "3":
				choix = "supprimer";
				break;
		}
		
		// pour envoyer des donn�es vers une autre servlet, il existe
		// plusieurs moyens :
		// - cr�er et utiliser une querystring
		// - stocker les donn�es � transmettre dans la collection d'attribut
		//   de l'objet request
		// - stocker les donn�es � transmettre dans la session
		// - d'autres choix sont possibles (le contexte de l'application)
		// par exemple - mais, attention, dans ce dernier cas, ces donn�es
		// seront accessibles � TOUS les utilisateurs
			
		
		// Ici on va utiliser l'objet request pour transmettre les donn�es 
		request.setAttribute("choixUtilisateur", choix);
				
		// r�cup�rer l'information des 2 cases � cocher ayant le m�me nom
		String[] tbOptionsUtilisateur = request.getParameterValues("optionsAdmin");
		if (tbOptionsUtilisateur != null){
			for(int i=0; i<tbOptionsUtilisateur.length; i++){
				if(tbOptionsUtilisateur[i].equalsIgnoreCase("utiliserDB"))
					request.setAttribute("db", "oui");
				
				if(tbOptionsUtilisateur[i].equalsIgnoreCase("envoyerEmail"))
					request.setAttribute("email", "oui");
			}
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/TraitementHelper");
		dispatcher.forward(request, response); // jamais de context root derriere forward - traitement dans serveur
		
		// r�cup�rer la valeur s�lectionn�e des boutons radio
		String optionRadio = request.getParameter("groupeRadio");
		
	} // fin doPost()

}// fin classe TraitementMenuChoisir
