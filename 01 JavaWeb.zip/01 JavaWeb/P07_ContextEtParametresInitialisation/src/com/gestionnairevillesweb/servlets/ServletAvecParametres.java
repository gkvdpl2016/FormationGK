package com.gestionnairevillesweb.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletAvecParametres")
public class ServletAvecParametres extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletAvecParametres() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// R�cup�rer le/les param�tre/s personnalis�/s
		// 'Dans mon cas, il n'y a qu'un seul: codeSecret)
		// Pour le faire, je dois utiliser la configuration de la servlet
		
		ServletConfig config = getServletConfig();
		
		// r�cup�rer la param�tre 'codeSecret':
		String codePerso = config.getInitParameter("codeSecret");
		
		// r�cup�rer les param�tres communs � toutes les servlets (param�tres du content)
		// Pour cela, on utilise le contexte de l'application
		ServletContext contexteApplication = getServletContext();
		
		String urlBase = contexteApplication.getInitParameter("urlDb");
		String vMax = contexteApplication.getInitParameter("vMax");
		
		// r�cup�rer, incr�menter, red�poser la valeur du nombre d'acc�s
		
		// r�cup�rer la valeur d�pos�e pr�c�dement
		Object obj = contexteApplication.getAttribute("nbTotalAccess");
		
		int nbAcces;
		
		// Quand cette valeur est r�cup�r�e la 1ere fois, l'objet r�cup�r� 
		// n'existe pas et la variable obj contient null
		// Je dois donc analyser ce cas de figure:
		if (obj != null) // la valeur a d�j� �t� d�pos�e (elle existe)
			nbAcces = ((Integer) obj).intValue() + 1;
		else
			nbAcces = 1;
		
		// d�poser la nouvelle valeur � la m�me cl�
		contexteApplication.setAttribute("nbTotalAccess", nbAcces);
		
		String html = "<html><body>";
		
		html += "Code secret : <b>" + codePerso + "</b><br/>URL base de donn�es <b>" +
				urlBase + "</b><br>Vitesse max sur autoroute: <b>" + vMax + "</b>"
				+ "<br/> Nb total acces : " + nbAcces;
		
		html += "</body></html>";
		
		response.getWriter().println(html);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
