package com.gestionnairevillesweb.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletAvecParametres2")
public class ServletAvecParametres2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletAvecParametres2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// R�cup�rer le/les param�tre/s personnalis�/s
		// 'Dans mon cas, il n'y a qu'un seul: codeSecret)
		// Pour le faire, je dois utiliser la configuration de la servlet
		
		ServletConfig config = getServletConfig();
		
		// r�cup�rer la param�tre 'codeSecret':
		String codePerso = config.getInitParameter("codeSecret");
		
		// Remarque : le code secret r�cup�r� sera null car ce param�tre d'initialisation
		// n'est disponible que pour ServletAvecParametres et pas pour
		// ServletAvecParametres2
		
		// r�cup�rer les param�tres communs � toutes les servlets (param�tres du content)
		// Pour cela, on utilise le contexte de l'application
		ServletContext contexteApplication = getServletContext();
		
		String urlBase = contexteApplication.getInitParameter("urlDb");
		String vMax = contexteApplication.getInitParameter("vMax");
		
		
		String html = "<html><body>";
		
		html += "Code secret : <b>" + codePerso + "</b><br/>URL base de donn�es <b>" +
				urlBase + "</b><br>Vitesse max sur autoroute: <b>" + vMax
				+ "</b>";
		
		html += "</body></html>";
		
		response.getWriter().println(html);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
