/*
 * Je veux perfectionner encore plus le test que je fais sur l'exception lev�e
 * lors de l'injection d'un objectif erron� (avec gt.setObjectif())
 * 
 * Pour cela, on va utiliser une r�gle (rule)
 * 
 * Une r�gle contient une condition ou plusieurs condition � tester.
 * Il existe des r�gles pr�d�finies (voir j-unit... Rules)
 * mais en cr�er d'autres personnalis�es.
 * 
 * Une r�gle une fois d�finie et configur�e agit sur toutes les m�thodes de test
 * de la classe
 * 
 * Elle agit aussi bien avant et apr�s le test (tout comme @Before et @After)
 * mais de fa�on plus personnalis�e et plus puissante
 * 
 * Dans notre cas on utilise la r�gle ExpectedException
 * 
 */
package com.etudiant;

import static org.junit.Assert.*;

import org.hamcrest.CoreMatchers;
import org.hamcrest.CoreMatchers.*;
import org.junit.runners.MethodSorters;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.rules.ExpectedException;

import com.etudiant.GestionnaireTirelire;;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire {

	private static GestionnaireTirelire gt;// = new GestionnaireTirelire();
	

	@Test
	@Category(CategorieA.class) // marquer cette m�thode de tests 
								// comme appartenant � la Cat�gorieA
	public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		System.out.println("Execution de a_testerMontantTotalZeroPourNouvelleInstance");
		assertEquals("Le montant total n'a pas �t� 0", 0, gt.getMontantTotal(),0);
	}
	
	@Test
	// d�clarer que la m�thode suivante appartient � 2 cat�gories
	@Category({CategorieA.class, CategorieB.class})
	public void b_verifierMontantApresDepot()
	{
		System.out.println("b_verifierMontantApresDepot");
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		
		assertEquals(20, gt.getMontantTotal(), 0);
		
		// ajouter 2 assertThat
		//assertThat(gt.getMontantTotal(), is(20));
		// pour pouvoir ecrire is(20) � la place de CoreMatchers.is(20)
		// je devrais faire un import static de la classe CoreMatchers
		
		// le test
		// assertThat(gt.getMontantTotal(), is(20));
		// �choue car, malgr� le fait que la valeur soit bonne
		// le type attentdu (int) ne correspond pas au type
		// retourn� par gt.getMontantTotal() qui est float (F)
		
		// je dois donc tester non pas is(20F)
		assertThat(gt.getMontantTotal(), CoreMatchers.is(20F));
		
		// @doc
		// - pour la liste des filtres (matches) JUnit : JUnitMatchers
		// - pour les matchers hamcrest : Matchers
	}
	
	@Test
	@Category(CategorieA.class)
	public void c_verifierMontantApresRetrait(){
		System.out.println("b_verifierMontantApresRetrait");
		gt.retirer(10);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
	
	@After
	public void apres(){
		System.out.println("Execution de la m�thode apres()");
	}
	
	@BeforeClass
	public static void beforeClass(){
		System.out.println("Ex�cution de m�thodeBeforeClass()");
	}
	
	
	@AfterClass
	public static void afterClass(){
		System.out.println("Ex�cution de m�thodeAfterClass()");
	}
	
	@Test(expected = ExceptionObjectifInvalide.class)
	@Category(CategorieB.class)
	public void testerExceptionObjectifInvalide() throws ExceptionObjectifInvalide{
		gt.setObjectif(-7);
		// comme setObjectif(-7) l�ve l'exception ExceptionObjectifInvalide,
		// le test r�ussit.
		
		// Si je change la valeur en 7 :
		// gt.setObjectif(7) ne l�ve l'exception attendu et le test
		// �choue car, malgr� le fait que la valeur soit bonne,
		
	}
	
	// d�finir une r�gle pr�d�finie de type ExpectedException
	@Rule
	public ExpectedException exceptionAttendue = ExpectedException.none();
		// on utilise none() pour ne pas configurer compl�tement la r�gle
		// ceci me permet:
		// - de ne pas rendre la r�gle op�rationnelle (car sinon la r�gle va
		// sur toutes les m�thodes de test de ma classe)
		// - de pr�ciser � chaque moment (pour chaque test) le type 
		// de l'exception attendue
		// Actuellement, � cause de none(), la r�gle ne fonctionne pas car
		// le type attendu n'existe pas, il sera pr�cis� plus tard
	
	@Test
	public void testerExceptionObjectifInvalideAvecRegle() throws ExceptionObjectifInvalide{
		// configurer la r�gle d�finie plus haut
		//exceptionAttendue.expect(com.etudiant.ExceptionObjectifInvalide.class);
		
		// donner le type de l'exception que j'attends
		exceptionAttendue.expect(com.etudiant.ExceptionObjectifInvalide.class);
		
		// pr�ciser le message
		exceptionAttendue.expectMessage("L'objectif ne peut pas �tre n�gatif"); // test echec si "pas" retir� du message 
		
		// Dans un 2e temps, changer le message attendu �
		// "L'objectif ne peut �tre n�gatif"
		// Remarque : la comparaison des chaines est sensible � la casse
		
		// Etape 2 :
		// - mettre en commentaire (�ventuellement) l'instruction pr�c�dente
		// exceptionAttendue.expectMessage("L'objectif ne peut pas �tre n�gatif");
		// et la remplacer avec:
		
		exceptionAttendue.expectMessage(CoreMatchers.containsString("n�gatif"));
		// tester avec "n�gatif", "N�gatif"
		
		gt.setObjectif(-7);
	}
	
	@Test(timeout=200) // La dur�e du test ne doit pas d�passer 200 millisecondes
	public void testerDureeExecutionMaximum()
	{
		//for(int i=0; i<1000000 ; i++)
			gt.deposer(2);
	}
} // fin classe TestsGestionTirelire
