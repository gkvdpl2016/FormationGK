package com.etudiant;

import org.junit.experimental.categories.Categories;
import org.junit.experimental.categories.Categories.ExcludeCategory;
import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

// cette classe d�finit une suite de tests
// cr�er une suite est form�e, dans un premier temps, de toutes 
// les m�thodes de test de classes BonjourJUnitTest et
// TestsGestionTirelire

// Puis, dans un 2e temps, � l'aide de l'annotation @Include,
// je demande l'�xection des m�thodes qui n'appartiennent
// qu'� la Cat�gorieA

@RunWith(Categories.class)   // attention, il faut remplacer Suite.class
							 // avec Categories.class

@Suite.SuiteClasses(	
					{ 	
						BonjourJUnitTest.class,
						TestsGestionTirelire.class
					})

@IncludeCategory(CategorieA.class) // sans cette annotation
								   // tous les tests de la suite seront
								   // ex�cut�s
								   // (mettre en commentaire pour voir)
//@ExcludeCategory(CategorieB.class)
public class SuiteTestsX {
	
}

// lancer la suite comme suit:
// clic droit sur le nom de la classe SuiteTestsGestionTirelire ->
// Run as -> JUnit test