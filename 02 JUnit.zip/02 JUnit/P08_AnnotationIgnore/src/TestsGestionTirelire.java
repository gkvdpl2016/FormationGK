/*
 *
 * L'annotation @Ignore est utilis�e pour ne pas ex�cuter un certain test.
 * 
 * Ceci peut �tre int�ressant si
 * - on conna�t le r�sultat du test ou alors
 * - le test est trop long et on veut acc�l�rer l'ex�cution de
 * l'ensemble de tests.
 * 
 */

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.etudiant.GestionnaireTirelire;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire {

	private static GestionnaireTirelire gt;// = new GestionnaireTirelire();
	

	
	@Test
	public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		System.out.println("Execution de a_testerMontantTotalZeroPourNouvelleInstance");
		assertEquals("Le montant total n'a pas �t� 0", 0, gt.getMontantTotal(),0);
	}
	
	@Test
	@Ignore
	public void b_verifierMontantApresDepot()
	{
		System.out.println("b_verifierMontantApresDepot");
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		assertEquals(20, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void c_verifierMontantApresRetrait(){
		System.out.println("c_verifierMontantApresRetrait");
		gt.retirer(10);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
	
	@After
	public void apres(){
		System.out.println("Execution de la m�thode apres()");
	}
	
	@AfterClass
	public static void methodeAfterClass()
	{
		System.out.println("Ex�cution de m�thodeAfterClass()");
	}
} // fin classe TestsGestionTirelire
