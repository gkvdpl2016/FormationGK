/*
 * Les m�thodes static d�cor�es avec @BeforeClass et @AfterClass
 * sont ex�cut�es une seule fois :
 * - 1a 1ere avant de commander l'ensemble de tests
 * - la 2e apr�s avoir termin� l'ensemble de tests
 * 
 */

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.etudiant.GestionnaireTirelire;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire {

	private static GestionnaireTirelire gt;// = new GestionnaireTirelire();
	

	
	@Test
	public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		System.out.println("Execution de a_testerMontantTotalZeroPourNouvelleInstance");
		assertEquals("Le montant total n'a pas �t� 0", 0, gt.getMontantTotal(),0);
	}
	
	@Test
	public void b_verifierMontantApresDepot()
	{
		System.out.println("b_verifierMontantApresDepot");
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		assertEquals(20, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void c_verifierMontantApresRetrait(){
	//public void b_verifierMontantApresRetrait(){
		// Gestionnaire gt = new GestionnaireTirelire();
		gt.retirer(10);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
	
	@After
	public void apres(){
		System.out.println("Execution de la m�thode apres()");
	}
	
	@AfterClass
	public static void methodeAfterClass()
	{
		System.out.println("Ex�cution de m�thodeAfterClass()");
	}
} // fin classe TestsGestionTirelire
