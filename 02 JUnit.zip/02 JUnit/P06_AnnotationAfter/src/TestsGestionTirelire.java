/*
 * 
 * Une m�thode d�cor�e @After est ex�cut�e apr�s chaque test
 * 
 */

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.etudiant.GestionnaireTirelire;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire 
{
	// Mauvaise solution
	private static GestionnaireTirelire gt;// = new GestionnaireTirelire();
	
	
	// testons, pour commencer, si le montant total est 0 quand
	// une instance de GestionnaireTirelire est cr��e
	// Le nom de la m�thode de test est libre mais il vaut mieux
	// d'en utiliser un qui est parlant
	
	@Test
	public void d_testerMontantTotalZeroPourNouvelleInstance()
	// public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		//GestionnaireTirelire gt = new GestionnaireTirelire();
		assertEquals("Le motnant total n'a pas �t� 0", 0, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void b_verifierMontantApresDepot()
	//public void c_verifierMontantApresDepot()
	{
		//GestionnaireTirelire gt = new GestionnaireTirelire();
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		
		// il existe aussi la version assertEquals() sans message
		assertEquals(20, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void c_verifierMontantApresRetrait(){
	//public void b_verifierMontantApresRetrait(){
		// Gestionnaire gt = new GestionnaireTirelire();
		gt.retirer(10);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
}
