package com.etudiant;

public class ExceptionObjectifInvalide extends Exception {

	public ExceptionObjectifInvalide(){
		super();
	}
	
	public ExceptionObjectifInvalide(String s){
		super(s);
	}
	
}
