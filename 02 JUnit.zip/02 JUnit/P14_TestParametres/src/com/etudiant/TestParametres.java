package com.etudiant;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)	// je d�clare que cette classe est
								// une classe des tests param�tr�s
public class TestParametres 
{
	// cr�er le GestionnaireTirelire dont les m�thodes �tre test�es
	private static GestionnaireTirelire gt = new GestionnaireTirelire();
	
	// la valeur donn�e (fournie) en entr�e
	private int entree;
	
	// la valeur qui est attendue en sortie
	private int sortieAttendue;
	
	// pr�ciser les param�tres (les valeurs en entr�e 
	// et les valeurs attendues en sortie) � l'aide d'une m�thode
	// qui retourne un objet de type List
	// contenant des tableaux de 2 valeurs (valeur en entr�e et valeur atendue en sortie)
	
	// Une telle m�thode doit �tre annot�e avec @Parameters
	@Parameters
	public static List<Object[]> donnees()
	{
		return Arrays.asList(new Object[][]
				{
					// valeur en entr�e, valeur attendue en sortie
					{4, 4}, // on d�pose 4, on doit trouver un montant total de 4
					{3, 7}, // on d�pose 3, on doit trouver 7
					{-7, 0}, // on retire 7, on doit trouver 0
					{10, 10}, // {10, 11}
					{2, 12},
					{-15, 12} // on veut retirer 15 mais, comme cette somme
							  // n'est pas disponible, l'op�ration n'a pas lieu
							  // et le montant doit rester celui devznt l'operation
							  // Si la place de (15-12) je mets (-15, -3)
							  // le test doit signaler une erreur
				});
	} // fin m�thode donn�es()

	// constructeur
	public TestParametres(int entree, int sortieAttendue){
		this.entree = entree;
		this.sortieAttendue = sortieAttendue;
	}
	
	// cr�er la m�thode de test
	@Test
	public void test()
	{
		// a-t-on � faire � un d�p�t ou un retrait ?
		if(entree >= 0)
			gt.deposer(entree);
		else{
			gt.retirer(-entree);
		}
		
		assertEquals(sortieAttendue, gt.getMontantTotal(), 0);
	}
	
} // fin classe
