
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.etudiant.GestionnaireTirelire;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire 
{
	private static GestionnaireTirelire gt;
	
	
	@Test
	public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		System.out.println("Execution de a_testerMontantTotalZeroPourNouvelleInstance");
		//GestionnaireTirelire gt = new GestionnaireTirelire();
		assertEquals("Le montant total n'a pas �t� 0", 0, gt.getMontantTotal(),0);
	}
	
	@Test
	public void b_verifierMontantApresDepot()
	{
		System.out.println("b_verifierMontantApresDepot");
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		assertEquals(20, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void c_verifierMontantApresRetrait(){
	//public void b_verifierMontantApresRetrait(){
		// Gestionnaire gt = new GestionnaireTirelire();
		gt.retirer(20);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
}
