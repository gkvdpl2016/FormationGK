package com.etudiant;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

// cette classe d�finit une suite de tests

@RunWith(Suite.class)   // d�finir cette classe comme �tant une suite
@Suite.SuiteClasses(	// pr�ciser le contenu de la suite
					{ 	// tableau de classes qui font partie de la suite
						BonjourJUnitTest.class,
						TestsGestionTirelire.class
					})
public class SuiteTestsGestionTirelire {
	
}

// lancer la suite comme suit:
// clic droit sur le nom de la classe SuiteTestsGestionTirelire ->
// Run as -> JUnit test