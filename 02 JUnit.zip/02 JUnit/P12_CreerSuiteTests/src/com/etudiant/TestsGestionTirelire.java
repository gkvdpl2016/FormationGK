/*
 * On peut imposer une dur�e limite pour certaine m�thode de test
 * Cela peut-�tre fait � l'aide de l'attribut 'timeout' de l'annotation
 * @Test.
 * Le valeur de cet attribut doit �tre donn�e en millisecondes
 * 
 * Plus bas ((dans la m�thode testerDureeExecutionMaximum()) 
 * j'ai utilis� une boucle for pour rallonger l'ex�cution du test.
 * Mais je peux aussi ins�rer un Thread.sleep(200) dans la m�thode d�poser()
 * du projet � tester
 * 
 */
package com.etudiant;

import static org.junit.Assert.*;
import org.junit.runners.MethodSorters;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;

import com.etudiant.GestionnaireTirelire;;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestsGestionTirelire {

	private static GestionnaireTirelire gt;// = new GestionnaireTirelire();
	

	@Test
	public void a_testerMontantTotalZeroPourNouvelleInstance()
	{
		System.out.println("Execution de a_testerMontantTotalZeroPourNouvelleInstance");
		assertEquals("Le montant total n'a pas �t� 0", 0, gt.getMontantTotal(),0);
	}
	
	@Test
	public void b_verifierMontantApresDepot()
	{
		System.out.println("b_verifierMontantApresDepot");
		gt.deposer(20);
		
		assertEquals("Le montant total n'a pas �t� 0", 20, gt.getMontantTotal(), 0);
		assertEquals(20, gt.getMontantTotal(), 0);
	}
	
	@Test
	public void c_verifierMontantApresRetrait(){
		System.out.println("b_verifierMontantApresRetrait");
		gt.retirer(10);
		assertEquals(0, gt.getMontantTotal(), 0);

	}
	
	@Before
	public void initialiserTest(){
		System.out.println("Initialisation test");
		gt = new GestionnaireTirelire();
	}
	
	@After
	public void apres(){
		System.out.println("Execution de la m�thode apres()");
	}
	
	@AfterClass
	public static void afterClass(){
		System.out.println("Ex�cution de m�thodeAfterClass()");
	}
	
	@Test(expected = ExceptionObjectifInvalide.class)
	public void testerExceptionObjectifInvalide() throws ExceptionObjectifInvalide{
		gt.setObjectif(-7);
		// comme setObjectif(-7) l�ve l'exception ExceptionObjectifInvalide,
		// le test r�ussit.
		
		// Si je change la valeur en 7 :
		// gt.setObjectif(7) ne l�ve l'exception attendu et le test
		// �choue.
	}
	
	@Test(timeout=200) // La dur�e du test ne doit pas d�passer 200 millisecondes
	public void testerDureeExecutionMaximum()
	{
		//for(int i=0; i<1000000 ; i++)
			gt.deposer(2);
	}
} // fin classe TestsGestionTirelire
