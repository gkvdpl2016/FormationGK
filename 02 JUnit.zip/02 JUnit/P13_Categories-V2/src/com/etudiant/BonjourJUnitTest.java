package com.etudiant;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

// D�clarer l'appartenance de cette classe � la cat�gorie de tests
// Cat�gorie A
// Cela fait que toutes les m�thodes de test de cette classe appartiennent
// � CategorieA
@Category(CategorieA.class)
public class BonjourJUnitTest {

	@Test
	public void test() 
	{
		//fail("Not yet implemented");
	}

	
}
