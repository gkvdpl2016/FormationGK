package com.etudiant;

public interface CategorieB {

}
