package com.etudiant;

public interface CategorieA {

}
