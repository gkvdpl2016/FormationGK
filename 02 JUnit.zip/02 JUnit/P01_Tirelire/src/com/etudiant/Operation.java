package com.etudiant;

public class Operation {
	private int id;
	private float montantCourant;
	private float montantOperation;
	private String typeOrperation;
	
	public Operation(int id, float montantCourant, float montantOperation, String typeOrperation) {
		super();
		this.id = id;
		this.montantCourant = montantCourant;
		this.montantOperation = montantOperation;
		this.typeOrperation = typeOrperation;
	}

}
