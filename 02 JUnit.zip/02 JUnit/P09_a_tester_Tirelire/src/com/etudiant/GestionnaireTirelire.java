package com.etudiant;

import java.util.*;

public class GestionnaireTirelire 
{
	private float montantTotal = 0;
	private float objectif;
	private List<Operation> historique = new ArrayList<Operation>();
	private int idOperation = 0;
	
	public GestionnaireTirelire()
	{
		//montantTotal = 50;
		//System.out.println("Contruction instance GestionnaireTirelire");
	}
	
	public void deposer(int montant)
	{
		montantTotal += montant;
		// montantTotal += montantTotal + montant;
		historique.add(new Operation(idOperation++, montantTotal, montant, "depot"));
		/*
		try{
			Thread.sleep(110);
		}
		catch(Exception ex){};*/
	}
	
	public void retirer(int montant)
	{
		if (montantTotal - montant >= 0)
			montantTotal -= montant;
	}
	
	public float getMontantTotal()
	{
		return montantTotal;
	}
	
	public boolean estObjectifAtteint()
	{
		return montantTotal >= objectif;
	}
	
	public List<Operation> getHistorique()
	{
		return historique;
	}
	
	public void setObjectif(int objectif) throws ExceptionObjectifInvalide {
		if (objectif < 0)
			throw new ExceptionObjectifInvalide();
	}
}
