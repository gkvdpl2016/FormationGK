package com.etudiant;

public class ExceptionObjectifInvalide extends Exception {

}
