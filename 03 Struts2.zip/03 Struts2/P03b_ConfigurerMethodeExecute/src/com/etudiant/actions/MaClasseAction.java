/*
 * Dans ce projet, l'action analyse les donn�es saisies dans la page jsp
 * et prend une d�cision qui d�pend du r�sultat de cette analyse
 * 
 */

package com.etudiant.actions;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

public class MaClasseAction extends ActionSupport
{
	private static final long serialVersionUID = 1L;

	private String leCompteUtilisateur = null;
	private String leMotDePasse = null;
	
	//@Override
	//public String execute() throws Exception 
	public String maMethodeExecute() throws Exception 
	{
		System.out.println("Je suis dans execute()");
		
		// analyser la saisie
		
		// v�rifier la non nullit� des variables d'instance
		// leCompteUtilisateur et leMotDePasse
		if(leCompteUtilisateur == null || leMotDePasse == null)
		{
			// cr�er un message d'erreur
			this.addActionError("Compte utilisateur ou mot de passe invalide. R�essayer SVP.");
			return Action.ERROR;
		}
		
		if (leCompteUtilisateur.equals("admin") && leMotDePasse.equals("pwdadmin")){	
			return Action.SUCCESS;
		}
		
		else if (leCompteUtilisateur.equals("val") && leMotDePasse.equals("pwdval")){
			return "c_est_un_vip";
		}
		else
		{
			addActionError("Compte utilisateur ou mot de passe invalide. R�essayer SVP.");
			//return Action.ERROR;
			
			// on aurait pu retourner Action.INPUT
			return Action.INPUT;
		}
		
		
		
		
	}
	
	// Pour r�cup�rer les donn�es du formulaire, je d�finis des propri�t�s
	// ayant les noms identiques aux noms des champs de saisie cr��es avec
	// <s:textfield> et <s:password> dans le formulaire
	// On lie (bind), les champs de saisies � des propri�t�s de l'action

	// Bref, on lie le formulaire � l'action
	
	// Comme les noms de ces champs sont "compteUtilisateur" et "motDePasse",
	// les propri�t�s que je dois cr�er ici sont compteUtilisateur et motDePasse
	
	// Pour cr�er une propri�t� on cr�e ses accesseurs
	
	/* Accesseurs & modificateurs */ 
	public String getCompteUtilisateur() {
		return leCompteUtilisateur;
	}

	public void setCompteUtilisateur(String compteUtilisateur) {
		this.leCompteUtilisateur = compteUtilisateur;
	}

	public String getMotDePasse() {
		return leMotDePasse;
	}

	public void setMotDePasse(String motDePasse) {
		this.leMotDePasse = motDePasse;
	}
	
}
