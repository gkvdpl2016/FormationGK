package com.etudiant.actions;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.validator.annotations.RegexFieldValidator;
import com.opensymphony.xwork2.validator.annotations.RequiredStringValidator;
import com.opensymphony.xwork2.validator.annotations.StringLengthFieldValidator;
import com.opensymphony.xwork2.validator.annotations.Validations;
import com.opensymphony.xwork2.validator.annotations.ValidatorType;

public class MaClasseAction extends ActionSupport
{
	private static final long serialVersionUID = 1L;

	private String leCompteUtilisateur = null;
	private String leMotDePasse = null;
	
	@Validations
	(
		requiredStrings = 
		{
			@RequiredStringValidator
			(
				type = ValidatorType.SIMPLE, // de toute fa�on c'est la valeur par d�faut
				fieldName="compteUtilisateur",
				trim=true,
				message="Veuillez saisir le compte utilisateur"
			),
			
			@RequiredStringValidator
			(
				type = ValidatorType.SIMPLE, // de toute fa�on c'est la valeur par d�faut
				fieldName="motDePasse",
				trim=true,
				message="Veuillez saisir le mot de passe"
			)
		},
		
		stringLengthFields =
		{
			@StringLengthFieldValidator
			(
				fieldName="compteUtilisateur",
				trim=true,
				minLength="3",
				maxLength="7",
				message="Longueur erron�e du compte utilisateur"
			),
			
			@StringLengthFieldValidator
			(
				fieldName="motDePasse",
				trim=true,
				minLength="5",
				message="Le mot de passe est trop court"
			),
			
			@StringLengthFieldValidator
			(
				fieldName="motDePasse",
				trim=true,
				maxLength="10",
				message="Le mot de passe est trop long"
			)
		},
		
		regexFields =
		{
			@RegexFieldValidator(
					fieldName="motDePasse",
					trim=true,
					regexExpression="^[a-zA-Z_-]+[a-zA-Z_!?]*[0-9]+[a-zA-z0-9_!?]*$",
					message="Le mot de passe ne convient pas"
				)	
		}
		
	)
	
	@Override
	public String execute() throws Exception 
	{
		System.out.println("Je suis dans execute()");
		
		// analyser la saisie
		if(leCompteUtilisateur == null || leMotDePasse == null)
		{
			// cr�er un message d'erreur
			this.addActionError("Compte utilisateur ou mot de passe invalide. R�essayer SVP.");
			return Action.ERROR;
		}
		
		if (leCompteUtilisateur.equals("admin") && leMotDePasse.equals("pwdadmin0")){	
			return Action.SUCCESS;
		}
		
		else if (leCompteUtilisateur.equals("val") && leMotDePasse.equals("pwdval10")){
			return "c_est_un_vip";
		}
		else
		{
			addActionError("Compte utilisateur ou mot de passe invalide. R�essayer SVP.");
			//return Action.ERROR;
			
			// on aurait pu retourner Action.INPUT
			return Action.INPUT;
		}
		
	}
	
	public String getCompteUtilisateur() {
		System.out.println("getCompteUtilisateur()");
		return leCompteUtilisateur;
	}
	
	public void setCompteUtilisateur(String compteUtilisateur) {
		System.out.println("setCompteUtilisateur(" + compteUtilisateur + ")");
		this.leCompteUtilisateur = compteUtilisateur;
	}

	public String getMotDePasse() {
		return leMotDePasse;
	}
	
	public void setMotDePasse(String motDePasse) {
		this.leMotDePasse = motDePasse;
	}
	
}
