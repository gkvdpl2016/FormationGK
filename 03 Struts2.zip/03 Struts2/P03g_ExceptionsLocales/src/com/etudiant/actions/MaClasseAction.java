package com.etudiant.actions;

import com.opensymphony.xwork2.Action;

public class MaClasseAction 
{
	public String leverExceptionDivisionParZero()
	{
		java.util.Date date = new java.util.Date();
		long nbMilli = date.getTime();
		
		if(nbMilli % 2 == 0)
		{
			int resultat = 1/0;
		}
		else{
			int[] tb = {1, 5, 7};
			int i = tb[3];
		}
			
		return Action.SUCCESS;
	}
	
	public String leverExceptionTranstypage()
	{
		Object o = new Object();
		int[] tb = (int[]) o;
		return Action.SUCCESS;
	}
	
	public String leverExceptionIndex()
	{
		int[] tb = {1, 5, 7};
		int i = tb[3];
		return Action.SUCCESS;
	}
		
	public String leverExceptionInattendue()
	{
		Object o = null;
		System.out.println(o.toString());
		return Action.SUCCESS;
	}
}
