package com.etudiant.actions;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

// En g�n�ral, une classe d'action h�rite de dela superclasse ActionSupport
// mais ceci n'est pas une obligation
// public class MaClasseAction extends ActionSupport
public class MaClasseAction 
{
	// @Override - seulement le cas d'un Extends
	public String execute() throws Exception 
	{
		
		System.out.println("Action.SUCCESS: " + Action.SUCCESS);
		System.out.println("Action.ERROR: " + Action.ERROR);
		System.out.println("Action.INPUT: " + Action.INPUT);
		
		// Action est une interface qui contient des constances static
		// 	SUCCESS, ERROR, NONE, LOGIN, INPUT
		return "success";
		// ou alors
		//return Action.SUCCESS; // constante de la class Action, "success", "failed"...
		
		// on peut retourner une aure cha�ne de caract�res � condition 
		// que le fichier struts.xml en tienne compte 
		
		// en fonction de la cha�ne retourn�e, le fichier struts.xml
		// va retourner au client une vue ou autre
	}
}
