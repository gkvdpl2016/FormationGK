/*
 *  Une action peut produire des donn�es (ou s'en procurer)
 *  Ce projet montre comment ces donn�es peuvent �tre r�cup�r�s dans les vues
 *  
 */

package com.etudiant.actions;

import java.util.Date;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

// En g�n�ral, une classe d'action h�rite de dela superclasse ActionSupport
// mais ceci n'est pas une obligation
// public class MaClasseAction extends ActionSupport
public class MaClasseAction 
{
	
	private String msg = "Ceci est un message produit par l'action";
	
	// @Override - seulement le cas d'un Extends
	public String execute() throws Exception 
	{
		
		System.out.println("Action.SUCCESS: " + Action.SUCCESS);
		System.out.println("Action.ERROR: " + Action.ERROR);
		System.out.println("Action.INPUT: " + Action.INPUT);
		
		// Action est une interface qui contient des constances static
		// 	SUCCESS, ERROR, NONE, LOGIN, INPUT
		return "success";
		// ou alors
		//return Action.SUCCESS; // constante de la class Action, "success", "failed"...
		
		// on peut retourner une aure cha�ne de caract�res � condition 
		// que le fichier struts.xml en tienne compte 
		
		// en fonction de la cha�ne retourn�e, le fichier struts.xml
		// va retourner au client une vue ou autre
	}

	// d�finir une propri�t� "message" par le biais de ses accesseurs
	public String getMessage(){
		return msg;
	}
	
	public void setMessage(String msg){
		this.msg = msg;
	}

	// d�finir une propri�t� dateCourante en lecture seule
	public String getDateCourante()
	{
		return new Date().toString();
	}
}
